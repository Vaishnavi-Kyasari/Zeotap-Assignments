package com.zeotap.weather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherMonitorAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
