package com.zeotap.ruleengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RuleEngineAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RuleEngineAppApplication.class, args);
	}

}
