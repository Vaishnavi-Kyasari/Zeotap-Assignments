package com.zeotap.ruleengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuleEngineAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
