package com.example.RuleEnginAST.dto;

public class RuleRequestDTO {
    private String ruleString;

    // Getters and setters
    public String getRuleString() {
        return ruleString;
    }

    public void setRuleString(String ruleString) {
        this.ruleString = ruleString;
    }
}
