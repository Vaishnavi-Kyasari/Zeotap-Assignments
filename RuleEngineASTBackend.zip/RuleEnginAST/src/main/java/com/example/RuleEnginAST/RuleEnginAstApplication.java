package com.example.RuleEnginAST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RuleEnginAstApplication {

	public static void main(String[] args) {
		SpringApplication.run(RuleEnginAstApplication.class, args);
	}

}
