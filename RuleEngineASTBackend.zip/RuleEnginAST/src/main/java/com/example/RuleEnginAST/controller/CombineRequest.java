package com.example.RuleEnginAST.controller;

import java.util.List;

public class CombineRequest {

	  private List<String> rules;
	   

	    // Getters and Setters
	    public List<String> getRules() {
	        return rules;
	    }

	    public void setRules(List<String> rules) {
	        this.rules = rules;
	    }
}
